﻿using System.Windows.Controls;

namespace CarryRoutine 
{
    /// <summary>
    ///     Interaction logic for ExampleRoutineGui.xaml
    /// </summary>
    public partial class CarryRoutineGui : UserControl
    {
        public CarryRoutineGui()
        {
            InitializeComponent();
        }
    }
}