﻿namespace Resetter
{
    public class Messages
    {
        public static string ENTER_ZONE = "ENTER_ZONE";
        public static string LEAVE_ZONE = "LEAVE_ZONE";
        public static string START_RESETTING = "START_RESETTING";
        public static string STOP_RESETTING = "STOP_RESETTING";
        public static string UNSOCKET_GEMS = "UNSOCKET_GEMS";
        public static string SOCKET_ALL_GEMS_INTO_ITEMS = "SOCKET_ALL_GEMS_INTO_ITEMS";
        public static string SOCKET = "SOCKET";
        public static string CARRY_ENTER_ZONE = "CARRY_ENTER_ZONE";
        public static string CARRY_UNSOCKET_GEMS = "CARRY_UNSCOKET_GEMS";
        public static string CARRY_LEAVE_ZONE = "CARRY_LEAVE_ZONE";

    }
}